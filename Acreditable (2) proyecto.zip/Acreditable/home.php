<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pagos - Sistema de pagos</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="app-container">
    
    <aside class="sidebar">
        <div class="logo-container">
            <img src="Logo.jpeg" alt="Logo del sistema">
        </div>
        <nav class="nav-menu">
            <a href="index.php">
                <img src="iconos/inicio.png" alt="Icono Inicio" class="nav-icon">
                Inicio
            </a>
            <a href="home.php" class="active">
                <img src="iconos/pago.png" alt="pagos" class="nav-icon">
                Pagos
            </a>
            <a href="propietarios.php">
                <img src="iconos/propietario.png" alt="propietario" class="nav-icon">
                Propietarios
            </a>
            <a href="usuarios.php">
                <img src="iconos/usuario.png" alt="Usuarios" class="nav-icon">
                Usuarios
            </a>
            <a href="bitacora.php">
                <img src="iconos/historial.png" alt="historial" class="nav-icon">
                Bitacora
            </a>
            <a href="login.html">
                <img src="iconos/cerrar-sesion.png" alt="Salir" class="nav-icon">
                Salir
            </a>
            <a href="#">
                Ayuda
            </a>
        </nav>
    </aside>

    <main class="main-content">
        <header class="topbar">
            <h1><i class="fas fa-credit-card"></i>Sistema de Control de Pagos</h1>
        </header>

        <section class="content">
            <div class="content-header">
                <h2><i class="fas fa-list-ul"></i>Gestión de Pagos</h2>
                <p><i class="fas fa-clock"></i> Historial y registro de transacciones</p>
            </div>

            <div class="tarjeta-blanca">
                <div class="cabecera-tabla">
                    <h3><strong> <img src="iconos/Historial.png" alt="historial" class="nav-icon"> Historial de Pagos</strong></h3>
                    <a href="#" id="btnAbrirModal" class="boton-naranja"><i class="fas fa-plus-circle"></i>+ Registrar Pago</a>
                </div>

                <table class="tabla-moderna">
                    <thead>
                        <tr>
                            <th>Número</th>
                            <th>Usuario</th>
                            <th>Mes</th>
                            <th>Monto</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><strong>#001</strong></td>
                            <td>Juano Pérez</td>
                            <td>Enero 2026</td>
                            <td class="monto-resaltado">$200.00</td>
                            <td>
                                <a href="#" class="enlace-editar"><i class="fas fa-edit" style="margin-right: 4px;"></i> Editar</a>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </section>

        <footer class="footer">
            <p>&copy; 2026. Todos los derechos reservados.</p>
        </footer>
    </main>
</div>

</body>
</html>