<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Usuarios - Sistema de Pagos</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    
<div class="app-container">
    
    <aside class="sidebar">
        <div class="logo-container">
            <img src="Logo.jpeg" alt="Logo del sistema">
        </div>
        <nav class="nav-menu">
            <a href="index.php">
                <img src="iconos/inicio.png" alt="Icono Inicio" class="nav-icon">
                Inicio
            </a>
            <a href="home.php">
                <img src="iconos/pago.png" alt="pagos" class="nav-icon">
                Pagos
            </a>
            <a href="propietarios.php">
                <img src="iconos/propietario.png" alt="propietario" class="nav-icon">
                Propietarios
            </a>
            <a href="usuarios.php" class="active">
                <img src="iconos/usuario.png" alt="Usuarios" class="nav-icon">
                Usuarios
            </a>
            <a href="bitacora.php">
                <img src="iconos/historial.png" alt="historial" class="nav-icon">
                Bitacora
            </a>
            <a href="login.html">
                <img src="iconos/cerrar-sesion.png" alt="Salir" class="nav-icon">
                Salir
            </a>
            <a href="#">
                Ayuda
            </a>
        
        </nav>
    </aside>

    <main class="main-content">
        <header class="topbar">
            <h1><i class="fas fa-credit-card"></i>Sistema de Control de Pagos</h1>
        

        <div class="search-box"> 
            <i class="fas fa-search"></i>
            <input type="text" id="inputBuscar" placeholder="Buscar propietario...">
        </div>
        </header>

        <section class="content">
            <div class="content-header">
                <h2><i class="fas fa-chart-pie"></i>Gestión de usuarios</h2>
                <p><i class="fas fa-clock"></i>Lista de usuarios registrados</p>
            </div>

    </main>
   
</div>
</body>
</html>