<?php
$correo=$_POST['correo'];
$contra=$_POST['contrasena'];

?>