<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inicio - Sistema de pagos</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="app-container">
   
    <aside class="sidebar">
        <div class="logo-container">
            <img src="Logo.jpeg" alt="Logo del sistema">
        </div>
        <nav class="nav-menu">
            <a href="index.php" class="active">
                <img src="iconos/inicio.png" alt="Icono Inicio" class="nav-icon">
                Inicio
            </a>
            <a href="home.php">
                <img src="iconos/pago.png" alt="pagos" class="nav-icon">
                Pagos
            </a>
            <a href="propietarios.php">
                <img src="iconos/propietario.png" alt="propietario" class="nav-icon">
                Propietarios
            </a>
            <a href="usuarios.php">
                <img src="iconos/usuario.png" alt="Usuarios" class="nav-icon">
                Usuarios
            </a>
            <a href="bitacora.php">
                <img src="iconos/historial.png" alt="historial" class="nav-icon">
                Bitacora
            </a>
            <a href="login.html">
                <img src="iconos/cerrar-sesion.png" alt="Salir" class="nav-icon">
                Salir
            </a>
            <a href="#">
                Ayuda
            </a>
        
        </nav>
    </aside>

    <main class="main-content">
        <header class="topbar">
            <h1><i class="fas fa-credit-card"></i>Sistema de Control de Pagos</h1>
        </header>

        <section class="content">
            <div class="content-header">
                <h2><i class="fas fa-chart-pie"></i>Panel de Control</h2>
                <p><i class="fas fa-clock"></i>Resumen de pagos</p>
            </div>

            <div class="stats-container">
                <div class="stat-card">
                    <h3><i class="fas fa-arrow-up"></i>Saldo actual</h3>
                    <p class="stat-value">$12,450.00</p>
                    <span class="stat-trend positive"><i class="fas fa-arrow-up"></i> Este mes</span>
                </div>
                <div class="stat-card">
                    <h3><i class="fas fa-clock"></i>Pagos Pendientes</h3>
                    <p class="stat-value">24</p>
                    <span class="stat-trend warning"><i class="fas fa-exclamation-triangle"></i> Revisión necesaria</span>
                </div>
                <div class="stat-card">
                    <h3><i class="fas fa-exclamation-circle"></i>Pagos Vencidos</h3>
                    <p class="stat-value">$1,200.00</p>
                    <span class="stat-trend negative"><i class="fas fa-times-circle"></i> ¡Acción inmediata!</span>
                </div>
            </div>
        </section>

        <footer class="footer">
            <p>&copy; 2026. Todos los derechos reservados.</p>
        </footer>
    </main>
</div>

</body>
</html>