<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Propietarios - Sistema de pagos</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
   <div id="modalRegistro" class="modal-overlay">
    <div class="modal-content">
        <div class="modal-header">
            <h2>Registrar Propietario</h2>
            
            <span id="btnCerrarModal" class="btn-cerrar">X</span>
        </div>
        
        <!-- Formulario estándar sin funciones extrañas -->
        <form action="guardar_propietario.php" method="POST" id="formPropietario">
            <div class="form-group">
                <label for="nombre">Nombre y Apellido</label>
                <input type="text" id="nombre" name="nombre" placeholder="Ej. Juan Guerra" required>
            </div>

            <div class="form-group">
                <label for="cedula">Cédula</label>
                <input type="text" id="cedula" name="cedula" placeholder="Ej. 33.123.456" required>
            </div>

            <div class="form-group">
                <label for="telefono">Teléfono</label>
                <input type="text" id="telefono" name="telefono" placeholder="Ej. 0412-123456" required>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label for="numeroCalle">Número de calle</label>
                    <input type="text" id="numeroCalle" name="numeroCalle" placeholder="Ej. #12" required>
                </div>
                <div class="form-group">
                    <label for="numeroCasa">Número de casa</label>
                    <input type="text" id="numeroCasa" name="numeroCasa" placeholder="Ej. #3" required>
                </div>
            </div>

            <button type="submit" class="boton-naranja" style="width: 100%; margin-top: 15px;">Guardar Propietario</button>
        </form>
    </div>
</div>
</body>
</html>